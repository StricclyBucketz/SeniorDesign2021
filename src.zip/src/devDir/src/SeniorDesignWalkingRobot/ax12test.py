#!/usr/bin/env python3

from pyax12.connection import Connection
import time

# Connect to the serial port
serial_connection = Connection(port="/dev/ttyUSB0", baudrate=1000000)
dynamixel_id = 1

# Get the limits currently set for a motor. Argument is the ID.
# print("CW Limit: (goal position should be >=)")
# print(serial_connection.get_cw_angle_limit(9))
# print("CCW Limit: (goal position should be <=)")
# print(serial_connection.get_ccw_angle_limit(9))

# Set new limits for a motor.
# serial_connection.set_ccw_angle_limit(9, 118, degrees=False)
# serial_connection.set_cw_angle_limit(9, 600, degrees=False)

# To check the current position of up to three motors at a time.
print("Motor 9")
print(serial_connection.get_present_position(9, False))
 
# print("Motor 12")
# print(serial_connection.get_present_position(12, False))
# 
# print("Motor 12")
# print(serial_connection.get_present_position(12, False))
# time.sleep(1)


# Ping a dynamixel unit
#is_available = serial_connection.ping(dynamixel_id)
# print("Dynamixel 1 is available")
# print(is_available)

# These will move motors to specified positions
# serial_connection.goto(1, 518, speed=128, degrees=False) 
# serial_connection.goto(2, 770, speed=128, degrees=False)  
# serial_connection.goto(3, 376, speed = 128, degrees=False)
# serial_connection.goto(4, 528, speed=128, degrees=False) 
# serial_connection.goto(5, 544, speed=128, degrees=False) 
# serial_connection.goto(6, 819, speed = 128, degrees=False)
# time.sleep(2)
 
# serial_connection.goto(7, 523, speed=128, degrees=False) 
# serial_connection.goto(8, 447, speed=128, degrees=False)  
serial_connection.goto(9, 970, speed = 128, degrees=False)
# serial_connection.goto(10, 455, speed=128, degrees=False) 
# serial_connection.goto(11, 500, speed=128, degrees=False)  
# serial_connection.goto(12, 604, speed = 128, degrees=False)
# time.sleep(2)

# Position Library
def positionStand():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 512, speed = 128, degrees = False)
  serial_connection.goto(3, 512, speed = 128, degrees = False)
  serial_connection.goto(4, 512, speed = 128, degrees = False)
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 512, speed = 128, degrees = False)
  serial_connection.goto(9, 512, speed = 128, degrees = False)
  serial_connection.goto(10, 512, speed = 128, degrees = False)
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def positionStepOff_RFUp():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 512, speed = 128, degrees = False)
  serial_connection.goto(3, 720, speed = 112, degrees = False)  # 512 -> 720 del:Gdel = 0.87395
  serial_connection.goto(4, 750, speed = 128, degrees = False)  # 512 -> 750 del:Gdel = 1
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 512, speed = 128, degrees = False)
  serial_connection.goto(9, 512, speed = 128, degrees = False)
  serial_connection.goto(10, 512, speed = 128, degrees = False)
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def positionStepOff_RFDown():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 512, speed = 128, degrees = False)
  serial_connection.goto(3, 720, speed = 128, degrees = False)
  serial_connection.goto(4, 750, speed = 128, degrees = False)
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 405, speed = 128, degrees = False)  # 512 -> 405 del:Gdel = 1
  serial_connection.goto(9, 455, speed = 56, degrees = False)   # 512 -> 455 del:Gdel = 0.43925
  serial_connection.goto(10, 565, speed = 63, degrees = False)  # 512 -> 565 del:Gdel = 0.49533
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def positionStepOff_Torso():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 512, speed = 128, degrees = False)
  serial_connection.goto(3, 720, speed = 128, degrees = False)
  serial_connection.goto(4, 740, speed = 128, degrees = False)  # 750 -> 740 del:Gdel = 1
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 405, speed = 128, degrees = False)
  serial_connection.goto(9, 455, speed = 128, degrees = False)
  serial_connection.goto(10, 565, speed = 128, degrees = False)
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def positionLStep_RLStraight():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 512, speed = 128, degrees = False)
  serial_connection.goto(3, 512, speed = 117, degrees = False)  # 720 -> 512 del:Gdel = 0.91228
  serial_connection.goto(4, 512, speed = 128, degrees = False)  # 740 -> 512 del:Gdel = 1
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 405, speed = 128, degrees = False)
  serial_connection.goto(9, 455, speed = 128, degrees = False)
  serial_connection.goto(10, 565, speed = 128, degrees = False)
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def positionLStep_LLegForward():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 512, speed = 128, degrees = False)
  serial_connection.goto(3, 512, speed = 128, degrees = False)
  serial_connection.goto(4, 512, speed = 128, degrees = False)
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 512, speed = 45, degrees = False)  # 405 -> 512 del:Gdel = 0.34853
  serial_connection.goto(9, 304, speed = 63, degrees = False)  # 455 -> 304 del:Gdel = 0.49186
  serial_connection.goto(10, 295, speed = 128, degrees = False) # 565 -> 205 del:Gdel = 1
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def positionLStep_LFDown():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 620, speed = 128, degrees = False)  # 512 -> 620 del:Gdel = 1
  serial_connection.goto(3, 570, speed = 69, degrees = False)   # 512 -> 570 del:Gdel = 0.53704
  serial_connection.goto(4, 464, speed = 57, degrees = False)   # 512 -> 464 del:Gdel = 0.44444
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 512, speed = 128, degrees = False)
  serial_connection.goto(9, 304, speed = 128, degrees = False)
  serial_connection.goto(10, 295, speed = 128, degrees = False)
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def positionLStep_Torso():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 620, speed = 128, degrees = False)
  serial_connection.goto(3, 570, speed = 128, degrees = False)
  serial_connection.goto(4, 464, speed = 128, degrees = False)
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 512, speed = 128, degrees = False)
  serial_connection.goto(9, 304, speed = 128, degrees = False)
  serial_connection.goto(10, 299, speed = 128, degrees = False) # 295 -> 299 del:Gdel = 1
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def positionRStep_LLegStraight():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 620, speed = 128, degrees = False)
  serial_connection.goto(3, 570, speed = 128, degrees = False)
  serial_connection.goto(4, 464, speed = 128, degrees = False)
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 512, speed = 128, degrees = False)
  serial_connection.goto(9, 512, speed = 125, degrees = False)  # 304 -> 512 del:Gdel = 0.97653
  serial_connection.goto(10, 512, speed = 128, degrees = False) # 299 -> 512 del:Gdel = 1
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def position_RLegForward():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 512, speed = 48, degrees = False)   # 620 -> 512 del:Gdel = 0.37762
  serial_connection.goto(3, 720, speed = 67, degrees = False)   # 570 -> 720 del:Gdel = 0.52448
  serial_connection.goto(4, 750, speed = 128, degrees = False)  # 464 -> 750 del:Gdel = 1
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 512, speed = 128, degrees = False)
  serial_connection.goto(9, 512, speed = 128, degrees = False)
  serial_connection.goto(10, 512, speed = 128, degrees = False)
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def positionRStep_RFDown():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 512, speed = 128, degrees = False)
  serial_connection.goto(3, 720, speed = 128, degrees = False)
  serial_connection.goto(4, 750, speed = 128, degrees = False)
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 405, speed = 128, degrees = False)  # 512 -> 405 del:Gdel = 1
  serial_connection.goto(9, 455, speed = 68, degrees = False)   # 512 -> 455 del:Gdel = 0.53271
  serial_connection.goto(10, 565, speed = 63, degrees = False)  # 512 -> 565 del:Gdel = 0.49533
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def positionRStep_Torso():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 512, speed = 128, degrees = False)
  serial_connection.goto(3, 720, speed = 128, degrees = False)
  serial_connection.goto(4, 740, speed = 128, degrees = False) # 750 -> 740 del:Gdel = 1
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 405, speed = 128, degrees = False)
  serial_connection.goto(9, 455, speed = 128, degrees = False)
  serial_connection.goto(10, 565, speed = 128, degrees = False)
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def closeStepL():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 512, speed = 64, degrees = False)   # 620 -> 512 del:Gdel = 0.49770
  serial_connection.goto(3, 512, speed = 34, degrees = False)   # 570 -> 512 del:Gdel = 0.26728
  serial_connection.goto(4, 512, speed = 28, degrees = False)   # 464 -> 512 del:Gdel = 0.22120
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 512, speed = 128, degrees = False)
  serial_connection.goto(9, 512, speed = 123, degrees = False)  # 304 -> 512 del:Gdel = 0.95852
  serial_connection.goto(10, 512, speed = 128, degrees = False) # 295 -> 512 del:Gdel = 1
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

def closeStepR():
  serial_connection.goto(1, 512, speed = 128, degrees = False)
  serial_connection.goto(2, 512, speed = 128, degrees = False)
  serial_connection.goto(3, 512, speed = 117, degrees = False)  # 720 -> 512 del:Gdel = 0.91228
  serial_connection.goto(4, 512, speed = 128, degrees = False)  # 740 -> 512 del:Gdel = 1
  serial_connection.goto(5, 512, speed = 128, degrees = False)
  serial_connection.goto(6, 512, speed = 128, degrees = False)
  serial_connection.goto(7, 512, speed = 128, degrees = False)
  serial_connection.goto(8, 512, speed = 60, degrees = False)  # 405 -> 512 del:Gdel = 0.46930
  serial_connection.goto(9, 512, speed = 32, degrees = False)  # 455 -> 512 del:Gdel = 0.25000
  serial_connection.goto(10, 512, speed = 30, degrees = False) # 565 -> 512 del:Gdel = 0.23246
  serial_connection.goto(11, 512, speed = 128, degrees = False)
  serial_connection.goto(12, 512, speed = 128, degrees = False)

# Close the serial connection
serial_connection.close()